#include "text_editor.h"
#include<iostream>
#include<cstring>
using namespace std;
template <class T>
list <T>::list()
{
	line = 0;
	next = 0;
}
template <class T>
list<T>::list(T l)
{
	line = l;
	next = 0;
}
template <class T>
text_editor<T>::text_editor(void)
{
	head = tail = 0;
	count = 0;
}

template <class T>
void text_editor<T>::add_line(T l)
{
	list<T>* newlist = new list<T>(l);
	if (count == 0)
		head = tail = newlist;
	else
	{
		tail->next = newlist;
		tail = newlist;
	}
	count++;
}
template <class T>
void text_editor<T>::insert_line(int lnumber, T l)
{
	list<T>* tmp = head;
	list<T>* newlist = new list<T>(l);
	if (lnumber == 0 || lnumber > count)
	{
		cout << "invalid line number" << endl;
	}
	else if (lnumber == 1)
	{
		newlist->next = head;
		head = newlist;
		count++;
	}
	else
	{
		list<T>* tmp = head;
		for (int i = 0; i < lnumber - 2; i++)
			tmp = tmp->next;
		newlist->next = tmp->next;
		tmp->next = newlist;
		count++;
	}

}
template <class T>
void text_editor<T>::deleteLine(int lineNumber)
{

	list<T>* tmp = head;
	if (lineNumber == 0 || lineNumber > count)
	{
		cout << "invalid line number" << endl;
	}

	else if (lineNumber == 1)
	{
		head = head->next;
		delete tmp;
		count--;
		cout << "line " << "'" << lineNumber << "'" << " is successfully deleted" << endl;
	}
	else
	{
		for (int i = 0; i < lineNumber - 2; i++)
			tmp = tmp->next;
		list<T>* del = tmp->next;
		tmp->next = del->next;
		delete del;
		if (lineNumber == count)
			tail = tmp;
		count--;
		cout << "line " << "'" << lineNumber << "'" << " is successfully deleted" << endl;
	}

}
template <class T>
T text_editor<T>::getLine(int lineNumber)
{
	list<T>* tmp = head;
	if (lineNumber == 0 || lineNumber > count)
	{
		T s = "invalid line number ";
		return s;
	}

	else
	{
		for (int i = 0; i < lineNumber - 1; i++)
			tmp = tmp->next;
		return tmp->line;
	}
}

template <class T>
void text_editor<T>::display() {
	list<T>* tmp = head;
	int lnumber = 1;
	while (tmp != 0) {

		cout << "line " << lnumber << " : " << tmp->line << endl;
		lnumber++;
		tmp = tmp->next;


	}

}
template <class T>
int text_editor<T>::size()
{
	return count;
}
template <class T>
void text_editor<T>::findreplace(string s1, string s2)
{
	
	list<T>* tmp = head;
	while (tmp != 0)
	{
		auto isfound = tmp->line.find(s1);
		for (int i = 0;i <= size();i++)
		{
			int s1len = s1.length();
			//auto isfound = tmp->line.find(s1);
			if (isfound != string::npos)
			{
				tmp->line.replace(tmp->line.find(s1), s1len, s2);
			}


			//tmp->line.replace(tmp->line.find(s1), s1.size(), s2);
			cout << "your replace text" << endl << tmp->line << endl;
			tmp = tmp->next;

		}
	}
}


template <class T>
text_editor<T>::~text_editor(void)
{

}
template <class T>
void text_editor<T>::findd(string s) {
	list<T>* tmp = head;
	int countt = 1;
	while (tmp != NULL) {
		auto isfound = tmp->line.find(s);
		for (int i = 0;i < count;i++)
		{
			/*auto isfound = tmp->line.find(s);*/

			if (isfound != string::npos) {
				//cout << "substring found at :" << isfound << '\n';
				cout << countt << "   " << endl;
				countt++;
				tmp = tmp->next;


			}

			else {

				break;
			}
		}
		//tmp = tmp->next;
	}

}

template <class T>
void text_editor<T> ::update(int lnumber, T text)
{
	list<T>* tmp = head;
	if (lnumber == 0 || lnumber > count)
	{
		cout << "invalied line number" << endl;

	}
	else if (lnumber == 1)
	{
		head->line = text;
	}
	else
	{
		list<T>* tmp = head;
		for (int i = 0; i < lnumber - 1; i++)

			tmp = tmp->next;
		tmp->line = text;

	}

}




