#pragma once
#include<iostream>
#include<string>
using namespace std;
#pragma once

template <class T>
class list
{
public:
	list<T>* next;
	string line;
	list();
	list(T l);
};
template<class T>
class text_editor
{
	int count;
	list <T>* head;
	list <T>* tail;
public:
	text_editor();
	void add_line(T);
	void insert_line(int, T);
	void deleteLine(int);
	T getLine(int);
	void findd(string s);
	void display();
	int size();
	void findreplace(string s1,string s2);
	void update(int,T);
	~text_editor();


};