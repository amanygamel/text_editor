#include <iostream>
using namespace std;
#include<string>
#include<cstring>
# include "text_editor.cpp"
string text, l, value,s1,s2;
int lnumber;
text_editor<string> td;

void mini_text_editor()
{
	cout << "******welcome to our text_editor*******" << endl;
	bool exitflag = false;
	while (!exitflag)
	{
		int choise;
		cout << endl;
		cout << "************************" << endl;
		cout << "enter 1 to add new line" << endl;
		cout << "enter 2 to insert line" << endl;
		cout << "enter 3 to display " << endl;
		cout << "enter 4 to delete a line " << endl;
		cout << "enter 5 to get a specfic line" << endl;
		cout << "enter 6 to find number of lines that contain your string" << endl;
		cout << "enter 7 to update line " << endl;
		cout << "enter 8 to return number of lines " << endl;
		cout << "enter 9 to replace two strings" << endl;
		cout << "enter 0 to exit" << endl;
		cout << "************************" << endl;
		cout << "please enter your choice" << endl;
		cin >> choise;
		switch (choise)
		{
		case 1:
		{
			cout << "enter your text line" << endl;

			cin.get();
			getline(cin, l);
			td.add_line(l);

			break;

		}
		case 2:
		{
			cout << "enter your text line" << endl;

			cin.get();
			getline(cin, text);
			cout << "enter line number you want to add a text" << endl;
			cin >> lnumber;
			td.insert_line(lnumber, text);

			break;

		}
		case 3:
		{

			td.display();
			break;
		}
		case 4:
		{
			cout << "please enter line number to delete" << endl;
			cin >> lnumber;
			td.deleteLine(lnumber);
			break;

		}
		case 5:
		{
			cout << "please enter line number " << endl;
			cin >> lnumber;
			cout << td.getLine(lnumber) << endl;
			break;

		}
		case 6:
		{
			string tex;
			cout << "Enter the string user checked" << endl;
			cin.get();
			getline(cin, tex);
			td.findd(tex);

			break;



		}
		case 7:
		{
			cout << "enter your text line" << endl;
			cin.get();
			getline(cin, l);
			cout << "enter line number you want to update  text" << endl;
			cin >> lnumber;
			td.update( lnumber,l);
			break;

		}
		case 8:
		{
			cout << "the size of list is" << endl;
			cout << td.size() << endl;
			break;
			
		}
		case 9:
		{
		cout << "enter your text line you want to replace it" << endl;
		cin.get();
		getline(cin, s1);
		cout << "enter your text line you want to replace by it" << endl;
		cin.get();
		getline(cin, s2);
		td.findreplace(s1, s2);
		break;
		}
		case 0:
		{
			exitflag = true;
			break;
		}
		default:
			cout << "please enter a valid choice" << endl;
			break;

		}

	}
}
int main()
{
	//td.add_line("this is our mini text editor");
	mini_text_editor();
	return 0;

}


